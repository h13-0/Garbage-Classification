
#include "stm32f10x.h"

#include "SystemClock.h"
#include "usart.h"
#include "Stepper.h"
#include "TIM_Init.h"

int main()
{
		//��ʼ��Systickϵͳʱ��
		SystemClockInit();
	
		//��ʼ������
		//uart_init(115200);
	
		//Stepper_TypeDef stepperConveyor = Stepper_Init(GPIOC, GPIO_Pin_15, GPIOA, GPIO_Pin_0);
	
		Stepper_TypeDef stepperSlider = Stepper_Init(GPIOC, GPIO_Pin_13, GPIOC, GPIO_Pin_14);
	
		Stepper_Forward(&stepperSlider, 50000, 5000);

		while(1);
}
